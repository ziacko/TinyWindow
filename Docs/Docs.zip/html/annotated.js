var annotated =
[
    [ "windowManager", "dd/d30/classwindowManager.html", "dd/d30/classwindowManager" ]
];