var annotated_dup =
[
    [ "windowManager", "da/dcf/classwindow_manager.html", "da/dcf/classwindow_manager" ]
];