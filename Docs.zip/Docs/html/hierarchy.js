var hierarchy =
[
    [ "std::error_category", null, [
      [ "windowManager::tinyWindowErrorCategory_t", "da/d67/classwindow_manager_1_1tiny_window_error_category__t.html", null ]
    ] ],
    [ "windowManager::window_t", "d2/df7/structwindow_manager_1_1window__t.html", null ],
    [ "windowManager", "da/dcf/classwindow_manager.html", null ]
];