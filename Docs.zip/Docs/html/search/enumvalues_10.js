var searchData=
[
  ['up',['up',['../d7/dc6/namespace_tiny_window_acfdcec6db7dfc633b20f0379e47abe2a.html#acfdcec6db7dfc633b20f0379e47abe2aa46c48bec0d282018b9d167eef7711b2c',1,'TinyWindow::up()'],['../d7/dc6/namespace_tiny_window_a6178d2f4dea186f684f6322237a597bb.html#a6178d2f4dea186f684f6322237a597bba46c48bec0d282018b9d167eef7711b2c',1,'TinyWindow::up()'],['../d7/dc6/namespace_tiny_window_a1e83ee003279928b4197621c9cf8205b.html#a1e83ee003279928b4197621c9cf8205ba46c48bec0d282018b9d167eef7711b2c',1,'TinyWindow::up()']]]
];
