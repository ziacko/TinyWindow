var searchData=
[
  ['name',['name',['../d2/df7/structwindow_manager_1_1window__t.html#afa05be64881c6e4704b5fb04fea2b836',1,'windowManager::window_t::name()'],['../da/d67/classwindow_manager_1_1tiny_window_error_category__t.html#a21b8d7c2ea9a9379fa7cbd91bf87a764',1,'windowManager::tinyWindowErrorCategory_t::name()']]],
  ['normal',['NORMAL',['../da/d3f/_tiny_window_8h.html#a2e01fa6f80acf17a527cc8b18b3f1688a1e23852820b9154316c7c06e2b7ba051',1,'TinyWindow.h']]],
  ['not_5finitialized',['NOT_INITIALIZED',['../da/dcf/classwindow_manager.html#aa73662903b3093b6716b2fe2d0994437aba09728d8f9a2a78f7752a588f060aa2',1,'windowManager']]],
  ['nullwindow',['nullWindow',['../da/dcf/classwindow_manager.html#a4ccd28cb480f6c06aafd9031543b240a',1,'windowManager']]]
];
