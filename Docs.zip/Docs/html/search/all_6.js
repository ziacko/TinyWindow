var searchData=
[
  ['get',['get',['../db/d3d/class_tiny_window_1_1error_category__t_a8a885291fb4c881884ce9dd0d36d0665.html#a8a885291fb4c881884ce9dd0d36d0665',1,'TinyWindow::errorCategory_t']]],
  ['getmousepositioninscreen',['GetMousePositionInScreen',['../d8/d4d/class_tiny_window_1_1window_manager_a415c0698c14726febde19966c1959df6.html#a415c0698c14726febde19966c1959df6',1,'TinyWindow::windowManager']]],
  ['getnumwindows',['GetNumWindows',['../d8/d4d/class_tiny_window_1_1window_manager_a3336a4241b609bfe1bc49fbc726cb299.html#a3336a4241b609bfe1bc49fbc726cb299',1,'TinyWindow::windowManager']]],
  ['getscreenresolution',['GetScreenResolution',['../d8/d4d/class_tiny_window_1_1window_manager_adcd7cfe4ec046352eb834752c33e1502.html#adcd7cfe4ec046352eb834752c33e1502',1,'TinyWindow::windowManager']]]
];
