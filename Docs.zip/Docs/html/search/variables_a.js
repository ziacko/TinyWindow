var searchData=
[
  ['position',['position',['../d2/df7/structwindow_manager_1_1window__t_a95f18475c6dc37876f4e1c28c2efca86.html#a95f18475c6dc37876f4e1c28c2efca86',1,'windowManager::window_t']]]
];
