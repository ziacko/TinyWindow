var searchData=
[
  ['windowhandle',['windowHandle',['../d2/df7/structwindow_manager_1_1window__t.html#ad45c3c8b3721ec8e6631f9600a84d868',1,'windowManager::window_t']]],
  ['windowlist',['windowList',['../da/dcf/classwindow_manager.html#a13bc041881348ab8036120aa3a9fa2e8',1,'windowManager']]]
];
