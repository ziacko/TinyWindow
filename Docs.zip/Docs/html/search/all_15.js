var searchData=
[
  ['zero',['Zero',['../d2/d6a/struct_tiny_window_1_1ui_vec2_ab968cd6087bbd94d661ff8fd21373592.html#ab968cd6087bbd94d661ff8fd21373592',1,'TinyWindow::uiVec2']]]
];
