var searchData=
[
  ['addwindow',['AddWindow',['../da/dcf/classwindow_manager.html#acdf212281a8195c8d7cbf78af9318fc3',1,'windowManager']]]
];
