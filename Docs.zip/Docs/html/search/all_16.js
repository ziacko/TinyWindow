var searchData=
[
  ['_7ewindowmanager',['~windowManager',['../d8/d4d/class_tiny_window_1_1window_manager_ac5464137b0e703acd1759cb9d07ba822.html#ac5464137b0e703acd1759cb9d07ba822',1,'TinyWindow::windowManager']]]
];
