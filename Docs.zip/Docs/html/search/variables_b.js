var searchData=
[
  ['resizeevent',['resizeEvent',['../d2/df7/structwindow_manager_1_1window__t_a39c56a096b1e7e4bf8af696e600fd10b.html#a39c56a096b1e7e4bf8af696e600fd10b',1,'windowManager::window_t']]],
  ['resolution',['resolution',['../d2/df7/structwindow_manager_1_1window__t_acf07ad8eb5474252b94221c18dc8bd6c.html#acf07ad8eb5474252b94221c18dc8bd6c',1,'windowManager::window_t']]]
];
