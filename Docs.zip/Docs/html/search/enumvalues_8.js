var searchData=
[
  ['maximized',['MAXIMIZED',['../da/d3f/_tiny_window_8h.html#a2e01fa6f80acf17a527cc8b18b3f1688a2f33d682f3a4e19c31ced6cb4fd022e3',1,'TinyWindow.h']]],
  ['middle',['MIDDLE',['../da/d3f/_tiny_window_8h.html#afed38c4501d93424593b6c288b7a94a4a43eedd8685eb86592022f8da962e3474',1,'TinyWindow.h']]],
  ['minimized',['MINIMIZED',['../da/d3f/_tiny_window_8h.html#a2e01fa6f80acf17a527cc8b18b3f1688a43245b4788b59a22d5357a7146c06deb',1,'TinyWindow.h']]]
];
