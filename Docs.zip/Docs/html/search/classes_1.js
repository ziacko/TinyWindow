var searchData=
[
  ['is_5ferror_5fcode_5fenum_3c_20tinywindow_3a_3aerror_5ft_20_3e',['is_error_code_enum&lt; TinyWindow::error_t &gt;',['../d7/d74/structstd_1_1is__error__code__enum_3_01_tiny_window_1_1error__t_01_4.html',1,'std']]]
];
