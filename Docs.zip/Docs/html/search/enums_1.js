var searchData=
[
  ['decorator_5ft',['decorator_t',['../d7/dc6/namespace_tiny_window_ac8709da4b59a519612b47f213539873c.html#ac8709da4b59a519612b47f213539873c',1,'TinyWindow']]]
];
