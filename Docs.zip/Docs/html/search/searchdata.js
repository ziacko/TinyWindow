var indexSectionsWithContent =
{
  0: "abcdefghiklmnprstuvw~",
  1: "tw",
  2: "cefrt",
  3: "adefghimnprstw~",
  4: "acdefiklmnprsvw",
  5: "t",
  6: "t",
  7: "abdefiklmnprtuw",
  8: "acdhps",
  9: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

