var searchData=
[
  ['name',['name',['../d2/df7/structwindow_manager_1_1window__t.html#afa05be64881c6e4704b5fb04fea2b836',1,'windowManager::window_t']]],
  ['nullwindow',['nullWindow',['../da/dcf/classwindow_manager.html#a4ccd28cb480f6c06aafd9031543b240a',1,'windowManager']]]
];
