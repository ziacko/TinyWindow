var searchData=
[
  ['removewindowbyindex',['RemoveWindowByIndex',['../da/dcf/classwindow_manager.html#a78b63b30076f2d98eae4764f26d3e9f5',1,'windowManager']]],
  ['removewindowbyname',['RemoveWindowByName',['../da/dcf/classwindow_manager.html#aca514ca4a83b8ff4d44b891e86857f2d',1,'windowManager']]],
  ['restorewindowbyindex',['RestoreWindowByIndex',['../da/dcf/classwindow_manager.html#a9c049d8ef0544070e23ae7bd53a59ad4',1,'windowManager']]],
  ['restorewindowbyname',['RestoreWindowByName',['../da/dcf/classwindow_manager.html#a422fc3c8235bc3629c1cd026963bb075',1,'windowManager']]]
];
