var searchData=
[
  ['linux_5fdecorator',['LINUX_DECORATOR',['../da/d3f/_tiny_window_8h.html#ae8edcb13424e0d212b4490fefa4e7ee0',1,'TinyWindow.h']]],
  ['linux_5ffunction',['LINUX_FUNCTION',['../da/d3f/_tiny_window_8h.html#a3c266d8c18dec30826eb3545a93bdabb',1,'TinyWindow.h']]]
];
