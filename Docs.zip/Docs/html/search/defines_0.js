var searchData=
[
  ['architecture_5fid',['ARCHITECTURE_ID',['../d3/d66/_c_make_c_x_x_compiler_id_8cpp_aba35d0d200deaeb06aee95ca297acb28.html#aba35d0d200deaeb06aee95ca297acb28',1,'CMakeCXXCompilerId.cpp']]]
];
