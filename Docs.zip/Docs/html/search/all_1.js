var searchData=
[
  ['bad',['BAD',['../da/d3f/_tiny_window_8h_a2e6caf3b61ce4de90e20d48e1c69bb3b.html#a2e6caf3b61ce4de90e20d48e1c69bb3baf1b68d66337a81cfa0d2076171cba2a8',1,'TinyWindow.h']]],
  ['bare',['BARE',['../da/d3f/_tiny_window_8h_a5bcb3e3555765c98cc041366d3d579b4.html#a5bcb3e3555765c98cc041366d3d579b4ad80b95b1abb9c8659fa4cc9d3d29bb71',1,'TinyWindow.h']]]
];
