var searchData=
[
  ['tinywindowmouseposition_5ft',['tinyWindowMousePosition_t',['../da/d3f/_tiny_window_8h_aea6d0d3b9475f09626a7e09541287a36.html#aea6d0d3b9475f09626a7e09541287a36',1,'TinyWindow.h']]],
  ['tinywindowposition_5ft',['tinyWindowPosition_t',['../da/d3f/_tiny_window_8h_a94ca6bb86bd659d9ffbfb8436535688e.html#a94ca6bb86bd659d9ffbfb8436535688e',1,'TinyWindow.h']]],
  ['tinywindowresolution_5ft',['tinyWindowResolution_t',['../da/d3f/_tiny_window_8h_adc9ee4f4c9aedaf0240719c4580c8a14.html#adc9ee4f4c9aedaf0240719c4580c8a14',1,'TinyWindow.h']]],
  ['tinywindowscreenmouseposition_5ft',['tinyWindowScreenMousePosition_t',['../da/d3f/_tiny_window_8h_a08fb357ddeac1233ae3058d1ef9ae80a.html#a08fb357ddeac1233ae3058d1ef9ae80a',1,'TinyWindow.h']]],
  ['tinywindowscreenresolution_5ft',['tinyWindowScreenResolution_t',['../da/d3f/_tiny_window_8h_a9685e97ef67c917612fafd0e100ddd72.html#a9685e97ef67c917612fafd0e100ddd72',1,'TinyWindow.h']]]
];
