var searchData=
[
  ['name',['name',['../da/d67/classwindow_manager_1_1tiny_window_error_category__t.html#a21b8d7c2ea9a9379fa7cbd91bf87a764',1,'windowManager::tinyWindowErrorCategory_t']]]
];
