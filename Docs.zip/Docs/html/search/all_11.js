var searchData=
[
  ['up',['UP',['../da/d3f/_tiny_window_8h_a2e6caf3b61ce4de90e20d48e1c69bb3b.html#a2e6caf3b61ce4de90e20d48e1c69bb3bafbaedde498cdead4f2780217646e9ba1',1,'UP():&#160;TinyWindow.h'],['../da/d3f/_tiny_window_8h_afc5314105ecb3f4bec5868fd81139437.html#afc5314105ecb3f4bec5868fd81139437afbaedde498cdead4f2780217646e9ba1',1,'UP():&#160;TinyWindow.h'],['../da/d3f/_tiny_window_8h_a91a71a29ba928f57783bed98adf6a359.html#a91a71a29ba928f57783bed98adf6a359afbaedde498cdead4f2780217646e9ba1',1,'UP():&#160;TinyWindow.h']]]
];
