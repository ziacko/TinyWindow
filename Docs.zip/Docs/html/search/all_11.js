var searchData=
[
  ['visualinfo',['visualInfo',['../d2/df7/structwindow_manager_1_1window__t.html#adcb5328e67768784897b1ab5cafad46e',1,'windowManager::window_t']]]
];
