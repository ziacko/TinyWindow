var searchData=
[
  ['right',['RIGHT',['../da/d3f/_tiny_window_8h.html#afed38c4501d93424593b6c288b7a94a4a21507b40c80068eda19865706fdc2403',1,'TinyWindow.h']]]
];
