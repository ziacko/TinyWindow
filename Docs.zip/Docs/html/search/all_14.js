var searchData=
[
  ['_7etinywindowerrorcategory_5ft',['~tinyWindowErrorCategory_t',['../da/d67/classwindow_manager_1_1tiny_window_error_category__t_a91954805682fcf9999d3aa506a66e481.html#a91954805682fcf9999d3aa506a66e481',1,'windowManager::tinyWindowErrorCategory_t']]],
  ['_7ewindowmanager',['~windowManager',['../da/dcf/classwindow_manager_a22699ef482e71752e5a95b7b034e1acc.html#a22699ef482e71752e5a95b7b034e1acc',1,'windowManager']]]
];
