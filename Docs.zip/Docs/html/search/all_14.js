var searchData=
[
  ['y',['y',['../d2/d6a/struct_tiny_window_1_1ui_vec2_a1b1f7bc0fa742143fd6cfd52688947a9.html#a1b1f7bc0fa742143fd6cfd52688947a9',1,'TinyWindow::uiVec2']]]
];
