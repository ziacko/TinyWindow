var searchData=
[
  ['readme_2emd',['README.md',['../d9/dd6/_r_e_a_d_m_e_8md.html',1,'']]],
  ['removewindowbyindex',['RemoveWindowByIndex',['../da/dcf/classwindow_manager_a78b63b30076f2d98eae4764f26d3e9f5.html#a78b63b30076f2d98eae4764f26d3e9f5',1,'windowManager']]],
  ['removewindowbyname',['RemoveWindowByName',['../da/dcf/classwindow_manager_aca514ca4a83b8ff4d44b891e86857f2d.html#aca514ca4a83b8ff4d44b891e86857f2d',1,'windowManager']]],
  ['resizeevent',['resizeEvent',['../d2/df7/structwindow_manager_1_1window__t_a39c56a096b1e7e4bf8af696e600fd10b.html#a39c56a096b1e7e4bf8af696e600fd10b',1,'windowManager::window_t']]],
  ['resolution',['resolution',['../d2/df7/structwindow_manager_1_1window__t_acf07ad8eb5474252b94221c18dc8bd6c.html#acf07ad8eb5474252b94221c18dc8bd6c',1,'windowManager::window_t']]],
  ['restorewindowbyindex',['RestoreWindowByIndex',['../da/dcf/classwindow_manager_a9c049d8ef0544070e23ae7bd53a59ad4.html#a9c049d8ef0544070e23ae7bd53a59ad4',1,'windowManager']]],
  ['restorewindowbyname',['RestoreWindowByName',['../da/dcf/classwindow_manager_a422fc3c8235bc3629c1cd026963bb075.html#a422fc3c8235bc3629c1cd026963bb075',1,'windowManager']]],
  ['right',['RIGHT',['../da/d3f/_tiny_window_8h_afed38c4501d93424593b6c288b7a94a4.html#afed38c4501d93424593b6c288b7a94a4a21507b40c80068eda19865706fdc2403',1,'TinyWindow.h']]]
];
