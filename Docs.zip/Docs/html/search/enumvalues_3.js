var searchData=
[
  ['existing_5fcontext',['EXISTING_CONTEXT',['../da/dcf/classwindow_manager_aa73662903b3093b6716b2fe2d0994437.html#aa73662903b3093b6716b2fe2d0994437a15cd3b2625cd6cfde78290c4f594571d',1,'windowManager']]]
];
